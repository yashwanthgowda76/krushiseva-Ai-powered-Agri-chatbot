# KrushiSeva-Agribot-
KrushiSeva is an AI-powered agriculture chatbot designed to assist farmers with real-time crop market prices, weather updates, and expert guidance
